// récupération du portrait identifié par son id 
let Portrait = document.getElementById('p1');

// si on clique sur le portrait : test sur le nom de l'image et changement (modification de la balise scr)
Portrait.onclick = () => {
  const mySrc = Portrait.getAttribute('src');
  if (mySrc === 'images/cobbe-portrait.jpg') {
    Portrait.setAttribute('src','images/chandos-portrait.jpg');
  } else {
    Portrait.setAttribute('src','images/cobbe-portrait.jpg');
  }
}

// récupération des deux objets identifiés par leur id 
let ButtonU = document.getElementById('bWelcome');
let myWelcome = document.getElementById('bienvenue');

// définition de la fonction setUserName : celle-ci stocke le nom rentré
function setUserName(){
  const myName = prompt('Merci de donner votre prénom');
  localStorage.setItem('name', myName);
  myWelcome.textContent = `Bienvenue  ${myName}`;
}

// test : si le champ name est vide : on relance la fonction setUserName
//Sinon, on affiche dans le bloc identifié myWelcome le message prévu 
if (!localStorage.getItem('name')) {
  setUserName();
} else {
  const storedName = localStorage.getItem('name');
  myWelcome.textContent = `Bienvenue  ${storedName}`;
}

// lancement de la fonction setUserName lorsque l'on clique sur le bouton

ButtonU.onclick = () => {
  setUserName();
}


//recupération des lignes masquées
const Lignes = document.getElementsByClassName("cache");
var bool = true ;

function CacheCache(){
    if (bool){
        for (var i = 0 ; i < Lignes.length; i++) 
            {
            Lignes[i].style.display='none' ;
            }   
        }
    else {for (var i = 0 ; i < Lignes.length; i++) 
                {
                 Lignes[i].style.display='table-row' ;
                }
        }
    bool = !bool
}

