<!DOCTYPE html>
<html lang="fr">
<link rel="stylesheet" type="text/css" href="feuille-style.css">
	<head>
        <meta charset="utf-8">
        <meta property="og:description" content="Description de la forme et du contenu
        des premières éditions du théâtre de William Shakespeare.">
        <meta property="og:title" content="Le corpus shakespearien">
        <meta property="article_author" content="Christelle Poux">
        <meta property="og:type" content="article">
        <meta property="og:url" content="https://corpusshakespeare.000webhostapp.com">
        <meta property="og:site_name" content="Corpus Shakespearien">
        <meta name="robots" content="index, nofollow">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
		<title> Réponse au questionnaire </title>
	</head>
	
	<body>
        <header class="bordure" style="height:80px ; vertical-align: middle; text-align:center; clear:both; ">
    <h1>Questionnaire</h1>
    </header>
    <div>
    <!--<nav class="bordure" style ="width:12%; float:left; height:100%; overflow:auto"> ><-->
    <nav>
    <ul class="a">
        <li class="b"><a class="lienbarre" href="index.html">Page stylée</a></li>
        <li class="b"><a class="lienbarre" href="index_brut.html">Page brute </a> </li>
        <li class="b"><a class="lienbarre" href="pagedyn.html"> Page dynamique </a> </li>
        <li class="b"><a class="lienbarre" href="questionnaire.html"> Questionnaire </a> </li>
        <li class="b"><a class="lienbarre" href="https://corpusshakespeare.000webhostapp.com/blog/wordpress/">Blog </a> </li>
    </ul>
    </nav>
    <h2> Validation du questionnaire </h2>


<?php

// test la présence d'un nom et d'un email 
if (($_POST['email'] == NULL) || ($_POST['nom'] == NULL))
{
	echo "Il faut un nom et une adresse email pour soumettre le formulaire." ;
    return;
}	
// fonction nettoyer  
function nettoyer($x){
	if ($x){
		$x = trim($x);
		$x = stripslashes($x);
		$x = htmlspecialchars($x);
	}
	return $x ;
} 
//récupération des champs après nettoyage
	$nom = nettoyer($_POST['nom']) ;
	$annee = nettoyer($_POST['annee']) ;
	$mail = nettoyer($_POST['email']) ;
	$piece = nettoyer($_POST['piece']) ;
	$perso = nettoyer($_POST['perso']) ;
 ?>

<?php
try
{
	$mysqlClient = new PDO('mysql:host=localhost;dbname=id17967883_corpus;charset=utf8','id17967883_cp', '(CorpusData2022)');
}
catch (Exception $e)
{
        die('Erreur : ' . $e->getMessage());
}

// connexion établie : maj de la base

$requete = 'INSERT INTO id17967883_corpus.id(nom, annee, mail, piece, perso) VALUES (:nom, :annee, :mail,	:piece, :perso)';
$InsertCorpus = $mysqlClient->prepare($requete);
$InsertCorpus->execute(['nom' => $nom, 'annee' => $annee, 'mail' => $mail, 
	'piece' => $piece, 'perso' => $perso, 
	]);

?>
<h3>Rappel de vos informations</h3>
<ul style="list-style-type: none;">   
<li class="liens"> <b>Nom</b> : <?php echo($nom); ?></li>
 <li class="liens"> <b>Email</b> : <?php echo($mail); ?></li>
  <li class="liens"> <b>Année de naissance : </b> : <?php echo($annee); ?> </li>
</ul>   





<?php
$sqlrequete = 'SELECT COUNT(nom) FROM id17967883_corpus.id';
$corpusStatement = $mysqlClient->prepare($sqlrequete);
$corpusStatement->execute();
$nbeins = $corpusStatement->fetchAll(PDO::FETCH_COLUMN,0);

$sqlreq = "SELECT count(perso) FROM id17967883_corpus.id WHERE perso = :perso" ;
$corpusStat = $mysqlClient->prepare($sqlreq);
$corpusStat->execute(['perso' => $perso]) ;
$nbeperso = $corpusStat->fetchAll(PDO::FETCH_COLUMN,0);
?>

<h3> Quelques informations anedoctiques </h3>
<ul style="list-style-type: none;">   
<li class="liens"> Vous êtes <?php echo $nbeperso[0]; ?>  à préférer <?php echo $perso; ?> </li>
 <li class="liens"> <?php echo $nbeins[0]; ?> personnes ont désormais répondu à ce formulaire, merci !</li>
 </ul>  




</body>
</html>

